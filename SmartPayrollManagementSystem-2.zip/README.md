# Smart Payroll Management System

## Requirements
- Java 17+
- Maven 3.9+
- MySQL 8+

## Database
Create a MySQL server. The application creates `payroll_db` automatically.

Edit:
`src/main/resources/application.properties`

Set:
`spring.datasource.password=YOUR_MYSQL_PASSWORD`

## Run
```bash
mvn clean spring-boot:run
```

Open:
http://localhost:8080

## Demo accounts
- Admin: `admin` / `Admin@123`
- HR: `hr` / `Hr@123`

Sample employee records are created automatically on the first run.

## Architecture
Spring Boot REST API + Spring Security + Spring Data JPA + MySQL + static HTML/CSS/JavaScript frontend.

## Main API groups
- `/api/auth`
- `/api/admin`
- `/api/hr/employees`
- `/api/hr/attendance`
- `/api/hr/leaves`
- `/api/hr/payroll`
- `/api/employee`

## Notes
This is a complete college-project foundation with real persistence, role authorization, payroll calculation, anomaly flagging, notifications, and a responsive frontend. Before deploying to a real organization, add HTTPS, CSRF protection appropriate to the chosen auth flow, stronger audit controls, secrets management, backup/recovery, and organization-specific statutory payroll/tax rules.
