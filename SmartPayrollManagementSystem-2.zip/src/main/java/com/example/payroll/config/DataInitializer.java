package com.example.payroll.config;

import com.example.payroll.entity.*;
import com.example.payroll.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import java.math.BigDecimal;
import java.time.LocalDate;

@Configuration
public class DataInitializer {
    @Bean
    CommandLineRunner seed(UserRepository users, DepartmentRepository deps, DesignationRepository desigs,
                           EmployeeRepository employees, EmployeeSalaryRepository salaries,
                           LeaveTypeRepository leaveTypes, PasswordEncoder encoder){
        return args -> {
            if(users.count()==0){
                User admin=new User();admin.setUsername("admin");admin.setPassword(encoder.encode("Admin@123"));admin.setRole(Role.ADMIN);users.save(admin);
                User hr=new User();hr.setUsername("hr");hr.setPassword(encoder.encode("Hr@123"));hr.setRole(Role.HR);users.save(hr);

                Department it=new Department();it.setName("IT");deps.save(it);
                Department ece=new Department();ece.setName("ECE");deps.save(ece);
                Designation dev=new Designation();dev.setName("Software Engineer");desigs.save(dev);
                Designation exec=new Designation();exec.setName("HR Executive");desigs.save(exec);

                LeaveType casual=new LeaveType();casual.setName("Casual Leave");casual.setDefaultDays(12);leaveTypes.save(casual);
                LeaveType sick=new LeaveType();sick.setName("Sick Leave");sick.setDefaultDays(10);leaveTypes.save(sick);
                LeaveType unpaid=new LeaveType();unpaid.setName("Unpaid Leave");unpaid.setDefaultDays(0);leaveTypes.save(unpaid);

                for(int i=1;i<=5;i++){
                    Employee e=new Employee();
                    e.setEmployeeCode(String.format("EMP%03d",i));
                    e.setFullName("Sample Employee "+i);
                    e.setEmail("employee"+i+"@example.com");
                    e.setJoiningDate(LocalDate.now().minusMonths(i));
                    e.setEmploymentStatus("ACTIVE");
                    e.setBasicSalary(BigDecimal.valueOf(25000+i*2000));
                    e.setDepartment(i%2==0?ece:it); e.setDesignation(dev);
                    employees.save(e);

                    EmployeeSalary s=new EmployeeSalary();s.setEmployee(e);
                    s.setHra(e.getBasicSalary().multiply(new BigDecimal("0.20")));
                    s.setTransportAllowance(new BigDecimal("1500"));
                    s.setOtherAllowance(new BigDecimal("1000"));
                    s.setOvertimeRate(new BigDecimal("150"));
                    salaries.save(s);
                }
            }
        };
    }
}
