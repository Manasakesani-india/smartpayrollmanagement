package com.example.payroll.controller;

import com.example.payroll.entity.*;
import com.example.payroll.repository.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/admin")
public class AdminController {
    private final UserRepository users; private final DepartmentRepository departments; private final DesignationRepository designations;
    private final AuditLogRepository audit; private final PasswordEncoder encoder;

    public AdminController(UserRepository u,DepartmentRepository d,DesignationRepository g,AuditLogRepository a,PasswordEncoder p){
        users=u;departments=d;designations=g;audit=a;encoder=p;
    }

    @GetMapping("/dashboard")
    public Map<String,Object> dashboard(){
        return Map.of("totalUsers",users.count(),"hrUsers",users.countByRole(Role.HR),
            "activeUsers",users.countByActive(true),"inactiveUsers",users.countByActive(false));
    }

    @GetMapping("/users") public List<User> users(){return users.findAll();}

    @PostMapping("/users/hr")
    public User createHr(@RequestParam String username,@RequestParam String password){
        if(users.findByUsername(username).isPresent()) throw new RuntimeException("Username already exists");
        User u=new User();u.setUsername(username);u.setPassword(encoder.encode(password));u.setRole(Role.HR);
        return users.save(u);
    }

    @PutMapping("/users/{id}/active")
    public User active(@PathVariable Long id,@RequestParam boolean value){
        User u=users.findById(id).orElseThrow();u.setActive(value);return users.save(u);
    }

    @GetMapping("/departments") public List<Department> departments(){return departments.findAll();}
    @PostMapping("/departments") public Department department(@RequestBody Department d){return departments.save(d);}
    @GetMapping("/designations") public List<Designation> designations(){return designations.findAll();}
    @PostMapping("/designations") public Designation designation(@RequestBody Designation d){return designations.save(d);}
    @GetMapping("/audit-logs") public List<AuditLog> audit(){return audit.findAll();}
}
