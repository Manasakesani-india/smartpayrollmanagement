package com.example.payroll.controller;

import com.example.payroll.entity.*;
import com.example.payroll.repository.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/hr/attendance")
public class AttendanceController {
    private final AttendanceRepository attendance;
    private final EmployeeRepository employees;
    public AttendanceController(AttendanceRepository a,EmployeeRepository e){attendance=a;employees=e;}

    @GetMapping public List<Attendance> all(){return attendance.findAll();}

    @PostMapping public Attendance create(@RequestBody Attendance a){
        if(a.getEmployee()==null || a.getEmployee().getId()==null) throw new RuntimeException("Employee required");
        a.setEmployee(employees.findById(a.getEmployee().getId()).orElseThrow());
        if(a.getCheckIn()!=null && a.getCheckOut()!=null){
            long minutes=java.time.Duration.between(a.getCheckIn(),a.getCheckOut()).toMinutes();
            a.setWorkingHours(minutes/60.0);
            a.setOvertimeHours(Math.max(0,(minutes/60.0)-8));
        }
        return attendance.save(a);
    }
}
