package com.example.payroll.controller;

import com.example.payroll.dto.LoginRequest;
import com.example.payroll.entity.User;
import com.example.payroll.repository.UserRepository;
import jakarta.servlet.http.*;
import jakarta.validation.Valid;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthenticationManager authManager;
    private final UserRepository users;

    public AuthController(AuthenticationManager a, UserRepository u){authManager=a;users=u;}

    @PostMapping("/login")
    public Map<String,Object> login(@Valid @RequestBody LoginRequest request, HttpServletRequest req){
        Authentication auth=authManager.authenticate(
            new UsernamePasswordAuthenticationToken(request.username(),request.password()));
        SecurityContextHolder.getContext().setAuthentication(auth);
        new HttpSessionSecurityContextRepository().saveContext(
            SecurityContextHolder.getContext(),req, null);
        User u=users.findByUsername(request.username()).orElseThrow();
        return Map.of("username",u.getUsername(),"role",u.getRole().name());
    }

    @GetMapping("/me")
    public Map<String,Object> me(Authentication auth){
        if(auth==null) return Map.of("authenticated",false);
        User u=users.findByUsername(auth.getName()).orElseThrow();
        return Map.of("authenticated",true,"username",u.getUsername(),"role",u.getRole().name());
    }
}
