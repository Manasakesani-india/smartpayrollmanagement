package com.example.payroll.controller;

import com.example.payroll.entity.*;
import com.example.payroll.repository.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/hr/employees")
public class EmployeeController {
    private final EmployeeRepository employees;
    private final DepartmentRepository departments;
    private final DesignationRepository designations;

    public EmployeeController(EmployeeRepository e,DepartmentRepository d,DesignationRepository g){
        employees=e;departments=d;designations=g;
    }

    @GetMapping public List<Employee> all(){return employees.findAll();}

    @GetMapping("/{id}") public Employee one(@PathVariable Long id){
        return employees.findById(id).orElseThrow(()->new RuntimeException("Employee not found"));
    }

    @PostMapping public Employee create(@RequestBody Employee input){
        if(employees.existsByEmployeeCode(input.getEmployeeCode()))
            throw new RuntimeException("Employee code already exists");
        if(input.getDepartment()!=null && input.getDepartment().getId()!=null)
            input.setDepartment(departments.findById(input.getDepartment().getId()).orElseThrow());
        if(input.getDesignation()!=null && input.getDesignation().getId()!=null)
            input.setDesignation(designations.findById(input.getDesignation().getId()).orElseThrow());
        return employees.save(input);
    }

    @PutMapping("/{id}") public Employee update(@PathVariable Long id,@RequestBody Employee input){
        Employee e=one(id);
        e.setFullName(input.getFullName()); e.setEmail(input.getEmail());
        e.setPhone(input.getPhone()); e.setAddress(input.getAddress());
        e.setGender(input.getGender()); e.setDateOfBirth(input.getDateOfBirth());
        e.setJoiningDate(input.getJoiningDate()); e.setEmploymentStatus(input.getEmploymentStatus());
        e.setBasicSalary(input.getBasicSalary());
        if(input.getDepartment()!=null && input.getDepartment().getId()!=null)
            e.setDepartment(departments.findById(input.getDepartment().getId()).orElseThrow());
        if(input.getDesignation()!=null && input.getDesignation().getId()!=null)
            e.setDesignation(designations.findById(input.getDesignation().getId()).orElseThrow());
        return employees.save(e);
    }

    @DeleteMapping("/{id}") public Map<String,String> delete(@PathVariable Long id){
        employees.deleteById(id); return Map.of("message","Employee deleted");
    }
}
