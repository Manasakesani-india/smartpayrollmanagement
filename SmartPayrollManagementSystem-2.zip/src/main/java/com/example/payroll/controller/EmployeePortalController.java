package com.example.payroll.controller;

import com.example.payroll.entity.*;
import com.example.payroll.repository.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/employee")
public class EmployeePortalController {
    private final EmployeeRepository employees; private final PayrollRepository payrolls;
    private final AttendanceRepository attendance; private final LeaveRepository leaves;
    private final NotificationRepository notifications;

    public EmployeePortalController(EmployeeRepository e,PayrollRepository p,AttendanceRepository a,LeaveRepository l,NotificationRepository n){
        employees=e;payrolls=p;attendance=a;leaves=l;notifications=n;
    }

    private Employee me(Authentication auth){
        return employees.findByUserUsername(auth.getName()).orElseThrow(()->new RuntimeException("Employee profile not found"));
    }

    @GetMapping("/profile") public Employee profile(Authentication auth){return me(auth);}
    @GetMapping("/attendance") public List<Attendance> attendance(Authentication auth){return attendance.findAll().stream().filter(x->x.getEmployee().getId().equals(me(auth).getId())).toList();}
    @GetMapping("/leaves") public List<LeaveRequest> leaves(Authentication auth){return leaves.findByEmployeeId(me(auth).getId());}
    @GetMapping("/payroll") public List<Payroll> payroll(Authentication auth){return payrolls.findByEmployeeId(me(auth).getId());}
    @GetMapping("/notifications") public List<Notification> notifications(Authentication auth){return notifications.findByUserUsernameOrderByCreatedAtDesc(auth.getName());}
}
