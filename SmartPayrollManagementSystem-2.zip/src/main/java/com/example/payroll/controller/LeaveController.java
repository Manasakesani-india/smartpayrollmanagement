package com.example.payroll.controller;

import com.example.payroll.entity.*;
import com.example.payroll.repository.*;
import org.springframework.web.bind.annotation.*;
import java.time.temporal.ChronoUnit;
import java.util.*;

@RestController
@RequestMapping("/api/hr/leaves")
public class LeaveController {
    private final LeaveRepository leaves; private final EmployeeRepository employees; private final LeaveTypeRepository types;
    private final NotificationRepository notifications;
    public LeaveController(LeaveRepository l,EmployeeRepository e,LeaveTypeRepository t,NotificationRepository n){
        leaves=l;employees=e;types=t;notifications=n;
    }

    @GetMapping public List<LeaveRequest> all(){return leaves.findAll();}

    @PostMapping public LeaveRequest apply(@RequestBody LeaveRequest x){
        if(x.getStartDate()==null||x.getEndDate()==null||x.getEndDate().isBefore(x.getStartDate()))
            throw new RuntimeException("Invalid leave dates");
        x.setEmployee(employees.findById(x.getEmployee().getId()).orElseThrow());
        x.setLeaveType(types.findById(x.getLeaveType().getId()).orElseThrow());
        x.setNumberOfDays((int)(ChronoUnit.DAYS.between(x.getStartDate(),x.getEndDate())+1));
        return leaves.save(x);
    }

    @PutMapping("/{id}/approve")
    public LeaveRequest approve(@PathVariable Long id){
        LeaveRequest x=leaves.findById(id).orElseThrow();
        x.setStatus(LeaveStatus.APPROVED); LeaveRequest saved=leaves.save(x);
        notifyEmployee(x,"Your leave request was approved.");
        return saved;
    }

    @PutMapping("/{id}/reject")
    public LeaveRequest reject(@PathVariable Long id){
        LeaveRequest x=leaves.findById(id).orElseThrow();
        x.setStatus(LeaveStatus.REJECTED); LeaveRequest saved=leaves.save(x);
        notifyEmployee(x,"Your leave request was rejected.");
        return saved;
    }

    private void notifyEmployee(LeaveRequest x,String msg){
        if(x.getEmployee().getUser()!=null){
            Notification n=new Notification();n.setUser(x.getEmployee().getUser());n.setMessage(msg);notifications.save(n);
        }
    }
}
