package com.example.payroll.controller;

import com.example.payroll.entity.*;
import com.example.payroll.repository.*;
import com.example.payroll.service.PayrollService;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping("/api/hr/payroll")
public class PayrollController {
    private final PayrollService service; private final PayrollRepository payrolls;
    public PayrollController(PayrollService s,PayrollRepository p){service=s;payrolls=p;}

    @GetMapping public List<Payroll> all(){return payrolls.findAll();}

    @PostMapping("/process")
    public Payroll process(@RequestParam Long employeeId,@RequestParam int month,@RequestParam int year){
        return service.process(employeeId,month,year);
    }

    @PutMapping("/{id}/approve")
    public Payroll approve(@PathVariable Long id){
        Payroll p=payrolls.findById(id).orElseThrow();
        p.setStatus(PayrollStatus.APPROVED); return payrolls.save(p);
    }

    @PutMapping("/{id}/complete")
    public Payroll complete(@PathVariable Long id){
        Payroll p=payrolls.findById(id).orElseThrow();
        if(p.getStatus()!=PayrollStatus.APPROVED) throw new RuntimeException("Payroll must be approved first");
        p.setStatus(PayrollStatus.PROCESSED);p.setProcessedAt(LocalDateTime.now());
        return payrolls.save(p);
    }
}
