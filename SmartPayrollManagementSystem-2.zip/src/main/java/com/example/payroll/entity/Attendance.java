package com.example.payroll.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name="attendance", uniqueConstraints=@UniqueConstraint(columnNames={"employee_id","workDate"}))
public class Attendance {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch=FetchType.EAGER, optional=false) private Employee employee;
    @Column(nullable=false) private LocalDate workDate;
    private LocalTime checkIn;
    private LocalTime checkOut;
    @Enumerated(EnumType.STRING) private AttendanceStatus status;
    private double workingHours;
    private double overtimeHours;

    public Long getId(){return id;}
    public Employee getEmployee(){return employee;}
    public void setEmployee(Employee v){employee=v;}
    public LocalDate getWorkDate(){return workDate;}
    public void setWorkDate(LocalDate v){workDate=v;}
    public LocalTime getCheckIn(){return checkIn;}
    public void setCheckIn(LocalTime v){checkIn=v;}
    public LocalTime getCheckOut(){return checkOut;}
    public void setCheckOut(LocalTime v){checkOut=v;}
    public AttendanceStatus getStatus(){return status;}
    public void setStatus(AttendanceStatus v){status=v;}
    public double getWorkingHours(){return workingHours;}
    public void setWorkingHours(double v){workingHours=v;}
    public double getOvertimeHours(){return overtimeHours;}
    public void setOvertimeHours(double v){overtimeHours=v;}
}
