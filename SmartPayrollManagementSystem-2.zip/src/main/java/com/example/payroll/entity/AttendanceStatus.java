package com.example.payroll.entity;

public enum AttendanceStatus {
    PRESENT, ABSENT, HALF_DAY, LEAVE
}
