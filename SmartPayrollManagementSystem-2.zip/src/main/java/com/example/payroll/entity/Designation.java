package com.example.payroll.entity;

import jakarta.persistence.*;

@Entity
@Table(name="designations")
public class Designation {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @Column(nullable=false, unique=true) private String name;

    public Long getId(){return id;}
    public String getName(){return name;}
    public void setName(String v){name=v;}
}
