package com.example.payroll.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name="employees")
public class Employee {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;

    @Column(unique=true, nullable=false) private String employeeCode;
    @Column(nullable=false) private String fullName;
    @Column(unique=true, nullable=false) private String email;
    private String phone;
    private String address;
    private String gender;
    private LocalDate dateOfBirth;
    private LocalDate joiningDate;
    private String employmentStatus = "ACTIVE";
    private BigDecimal basicSalary = BigDecimal.ZERO;

    @ManyToOne(fetch=FetchType.EAGER) private Department department;
    @ManyToOne(fetch=FetchType.EAGER) private Designation designation;
    @OneToOne(fetch=FetchType.LAZY) private User user;

    public Long getId(){return id;}
    public String getEmployeeCode(){return employeeCode;}
    public void setEmployeeCode(String v){employeeCode=v;}
    public String getFullName(){return fullName;}
    public void setFullName(String v){fullName=v;}
    public String getEmail(){return email;}
    public void setEmail(String v){email=v;}
    public String getPhone(){return phone;}
    public void setPhone(String v){phone=v;}
    public String getAddress(){return address;}
    public void setAddress(String v){address=v;}
    public String getGender(){return gender;}
    public void setGender(String v){gender=v;}
    public LocalDate getDateOfBirth(){return dateOfBirth;}
    public void setDateOfBirth(LocalDate v){dateOfBirth=v;}
    public LocalDate getJoiningDate(){return joiningDate;}
    public void setJoiningDate(LocalDate v){joiningDate=v;}
    public String getEmploymentStatus(){return employmentStatus;}
    public void setEmploymentStatus(String v){employmentStatus=v;}
    public BigDecimal getBasicSalary(){return basicSalary;}
    public void setBasicSalary(BigDecimal v){basicSalary=v;}
    public Department getDepartment(){return department;}
    public void setDepartment(Department v){department=v;}
    public Designation getDesignation(){return designation;}
    public void setDesignation(Designation v){designation=v;}
    public User getUser(){return user;}
    public void setUser(User v){user=v;}
}
