package com.example.payroll.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name="employee_salary")
public class EmployeeSalary {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @OneToOne(optional=false) private Employee employee;
    private BigDecimal hra=BigDecimal.ZERO;
    private BigDecimal transportAllowance=BigDecimal.ZERO;
    private BigDecimal otherAllowance=BigDecimal.ZERO;
    private BigDecimal overtimeRate=BigDecimal.ZERO;
    private BigDecimal bonus=BigDecimal.ZERO;
    private BigDecimal otherDeduction=BigDecimal.ZERO;

    public Long getId(){return id;}
    public Employee getEmployee(){return employee;}
    public void setEmployee(Employee v){employee=v;}
    public BigDecimal getHra(){return hra;}
    public void setHra(BigDecimal v){hra=v;}
    public BigDecimal getTransportAllowance(){return transportAllowance;}
    public void setTransportAllowance(BigDecimal v){transportAllowance=v;}
    public BigDecimal getOtherAllowance(){return otherAllowance;}
    public void setOtherAllowance(BigDecimal v){otherAllowance=v;}
    public BigDecimal getOvertimeRate(){return overtimeRate;}
    public void setOvertimeRate(BigDecimal v){overtimeRate=v;}
    public BigDecimal getBonus(){return bonus;}
    public void setBonus(BigDecimal v){bonus=v;}
    public BigDecimal getOtherDeduction(){return otherDeduction;}
    public void setOtherDeduction(BigDecimal v){otherDeduction=v;}
}
