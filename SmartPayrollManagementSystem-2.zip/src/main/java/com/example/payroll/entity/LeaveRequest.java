package com.example.payroll.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name="leaves")
public class LeaveRequest {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch=FetchType.EAGER, optional=false) private Employee employee;
    @ManyToOne(fetch=FetchType.EAGER, optional=false) private LeaveType leaveType;
    private LocalDate startDate;
    private LocalDate endDate;
    private int numberOfDays;
    private String reason;
    @Enumerated(EnumType.STRING) private LeaveStatus status=LeaveStatus.PENDING;
    private String hrComment;

    public Long getId(){return id;}
    public Employee getEmployee(){return employee;}
    public void setEmployee(Employee v){employee=v;}
    public LeaveType getLeaveType(){return leaveType;}
    public void setLeaveType(LeaveType v){leaveType=v;}
    public LocalDate getStartDate(){return startDate;}
    public void setStartDate(LocalDate v){startDate=v;}
    public LocalDate getEndDate(){return endDate;}
    public void setEndDate(LocalDate v){endDate=v;}
    public int getNumberOfDays(){return numberOfDays;}
    public void setNumberOfDays(int v){numberOfDays=v;}
    public String getReason(){return reason;}
    public void setReason(String v){reason=v;}
    public LeaveStatus getStatus(){return status;}
    public void setStatus(LeaveStatus v){status=v;}
    public String getHrComment(){return hrComment;}
    public void setHrComment(String v){hrComment=v;}
}
