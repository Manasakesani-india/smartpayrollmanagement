package com.example.payroll.entity;

import jakarta.persistence.*;

@Entity
@Table(name="leave_types")
public class LeaveType {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @Column(nullable=false, unique=true) private String name;
    private int defaultDays;

    public Long getId(){return id;}
    public String getName(){return name;}
    public void setName(String v){name=v;}
    public int getDefaultDays(){return defaultDays;}
    public void setDefaultDays(int v){defaultDays=v;}
}
