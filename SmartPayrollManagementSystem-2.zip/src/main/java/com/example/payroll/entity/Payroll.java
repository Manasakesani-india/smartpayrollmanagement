package com.example.payroll.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name="payroll", uniqueConstraints=@UniqueConstraint(columnNames={"employee_id","payMonth","payYear"}))
public class Payroll {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch=FetchType.EAGER, optional=false) private Employee employee;
    private int payMonth;
    private int payYear;
    private int workingDays;
    private int presentDays;
    private int leaveDays;
    private double overtimeHours;
    private BigDecimal basicSalary=BigDecimal.ZERO;
    private BigDecimal hra=BigDecimal.ZERO;
    private BigDecimal allowances=BigDecimal.ZERO;
    private BigDecimal overtimePay=BigDecimal.ZERO;
    private BigDecimal bonus=BigDecimal.ZERO;
    private BigDecimal grossSalary=BigDecimal.ZERO;
    private BigDecimal leaveDeduction=BigDecimal.ZERO;
    private BigDecimal otherDeductions=BigDecimal.ZERO;
    private BigDecimal totalDeductions=BigDecimal.ZERO;
    private BigDecimal netSalary=BigDecimal.ZERO;
    @Enumerated(EnumType.STRING) private PayrollStatus status=PayrollStatus.DRAFT;
    private boolean anomaly;
    private String anomalyMessage;
    private LocalDateTime processedAt;

    public Long getId(){return id;}
    public Employee getEmployee(){return employee;}
    public void setEmployee(Employee v){employee=v;}
    public int getPayMonth(){return payMonth;}
    public void setPayMonth(int v){payMonth=v;}
    public int getPayYear(){return payYear;}
    public void setPayYear(int v){payYear=v;}
    public int getWorkingDays(){return workingDays;}
    public void setWorkingDays(int v){workingDays=v;}
    public int getPresentDays(){return presentDays;}
    public void setPresentDays(int v){presentDays=v;}
    public int getLeaveDays(){return leaveDays;}
    public void setLeaveDays(int v){leaveDays=v;}
    public double getOvertimeHours(){return overtimeHours;}
    public void setOvertimeHours(double v){overtimeHours=v;}
    public BigDecimal getBasicSalary(){return basicSalary;}
    public void setBasicSalary(BigDecimal v){basicSalary=v;}
    public BigDecimal getHra(){return hra;}
    public void setHra(BigDecimal v){hra=v;}
    public BigDecimal getAllowances(){return allowances;}
    public void setAllowances(BigDecimal v){allowances=v;}
    public BigDecimal getOvertimePay(){return overtimePay;}
    public void setOvertimePay(BigDecimal v){overtimePay=v;}
    public BigDecimal getBonus(){return bonus;}
    public void setBonus(BigDecimal v){bonus=v;}
    public BigDecimal getGrossSalary(){return grossSalary;}
    public void setGrossSalary(BigDecimal v){grossSalary=v;}
    public BigDecimal getLeaveDeduction(){return leaveDeduction;}
    public void setLeaveDeduction(BigDecimal v){leaveDeduction=v;}
    public BigDecimal getOtherDeductions(){return otherDeductions;}
    public void setOtherDeductions(BigDecimal v){otherDeductions=v;}
    public BigDecimal getTotalDeductions(){return totalDeductions;}
    public void setTotalDeductions(BigDecimal v){totalDeductions=v;}
    public BigDecimal getNetSalary(){return netSalary;}
    public void setNetSalary(BigDecimal v){netSalary=v;}
    public PayrollStatus getStatus(){return status;}
    public void setStatus(PayrollStatus v){status=v;}
    public boolean isAnomaly(){return anomaly;}
    public void setAnomaly(boolean v){anomaly=v;}
    public String getAnomalyMessage(){return anomalyMessage;}
    public void setAnomalyMessage(String v){anomalyMessage=v;}
    public LocalDateTime getProcessedAt(){return processedAt;}
    public void setProcessedAt(LocalDateTime v){processedAt=v;}
}
