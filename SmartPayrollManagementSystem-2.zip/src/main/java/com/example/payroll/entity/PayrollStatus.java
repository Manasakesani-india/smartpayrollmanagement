package com.example.payroll.entity;

public enum PayrollStatus {
    DRAFT, PENDING, APPROVED, PROCESSED
}
