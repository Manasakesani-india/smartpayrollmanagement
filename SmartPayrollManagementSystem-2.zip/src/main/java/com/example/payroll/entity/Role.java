package com.example.payroll.entity;

public enum Role {
    ADMIN, HR, EMPLOYEE
}
