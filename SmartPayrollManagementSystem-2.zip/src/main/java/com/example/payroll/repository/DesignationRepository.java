package com.example.payroll.repository;
import com.example.payroll.entity.Designation;
import org.springframework.data.jpa.repository.JpaRepository;
public interface DesignationRepository extends JpaRepository<Designation,Long>{}
