package com.example.payroll.repository;
import com.example.payroll.entity.EmployeeSalary;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
public interface EmployeeSalaryRepository extends JpaRepository<EmployeeSalary,Long>{
    Optional<EmployeeSalary> findByEmployeeId(Long id);
}
