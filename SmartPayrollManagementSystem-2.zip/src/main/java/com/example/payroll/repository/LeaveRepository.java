package com.example.payroll.repository;
import com.example.payroll.entity.LeaveRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface LeaveRepository extends JpaRepository<LeaveRequest,Long>{
    List<LeaveRequest> findByEmployeeId(Long id);
    List<LeaveRequest> findByStatus(com.example.payroll.entity.LeaveStatus status);
}
