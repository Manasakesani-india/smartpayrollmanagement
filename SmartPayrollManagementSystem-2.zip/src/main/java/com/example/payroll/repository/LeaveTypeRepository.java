package com.example.payroll.repository;
import com.example.payroll.entity.LeaveType;
import org.springframework.data.jpa.repository.JpaRepository;
public interface LeaveTypeRepository extends JpaRepository<LeaveType,Long>{}
