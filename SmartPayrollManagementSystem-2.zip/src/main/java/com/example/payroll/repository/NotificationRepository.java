package com.example.payroll.repository;
import com.example.payroll.entity.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface NotificationRepository extends JpaRepository<Notification,Long>{
    List<Notification> findByUserUsernameOrderByCreatedAtDesc(String username);
}
