package com.example.payroll.repository;
import com.example.payroll.entity.Payroll;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
public interface PayrollRepository extends JpaRepository<Payroll,Long>{
    Optional<Payroll> findByEmployeeIdAndPayMonthAndPayYear(Long employeeId,int month,int year);
    List<Payroll> findByEmployeeId(Long employeeId);
}
