package com.example.payroll.repository;
import com.example.payroll.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
public interface UserRepository extends JpaRepository<User,Long>{
    Optional<User> findByUsername(String username);
    long countByRole(com.example.payroll.entity.Role role);
    long countByActive(boolean active);
}
