package com.example.payroll.security;

import org.springframework.context.annotation.*;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {
    @Bean PasswordEncoder passwordEncoder(){return new BCryptPasswordEncoder();}

    @Bean AuthenticationProvider authenticationProvider(CustomUserDetailsService service,
                                                          PasswordEncoder encoder){
        DaoAuthenticationProvider p=new DaoAuthenticationProvider(service);
        p.setPasswordEncoder(encoder);
        return p;
    }

    @Bean SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf->csrf.disable())
            .authorizeHttpRequests(auth->auth
                .requestMatchers("/", "/index.html", "/css/**", "/js/**",
                                 "/api/auth/login", "/api/auth/me").permitAll()
                .requestMatchers("/api/admin/**").hasRole("ADMIN")
                .requestMatchers("/api/hr/**").hasAnyRole("ADMIN","HR")
                .requestMatchers("/api/employee/**").hasAnyRole("ADMIN","HR","EMPLOYEE")
                .anyRequest().authenticated())
            .formLogin(form->form.disable())
            .logout(logout->logout
                .logoutUrl("/api/auth/logout")
                .invalidateHttpSession(true)
                .deleteCookies("JSESSIONID")
                .logoutSuccessHandler((req,res,auth)->res.setStatus(204)));
        return http.build();
    }
}
