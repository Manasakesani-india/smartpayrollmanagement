package com.example.payroll.service;

import com.example.payroll.entity.*;
import com.example.payroll.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.*;
import java.time.*;
import java.util.*;

@Service
public class PayrollService {
    private final EmployeeRepository employees;
    private final EmployeeSalaryRepository salaryRepo;
    private final AttendanceRepository attendance;
    private final LeaveRepository leaves;
    private final PayrollRepository payrolls;
    private final NotificationRepository notifications;
    private final UserRepository users;

    public PayrollService(EmployeeRepository e, EmployeeSalaryRepository s,
                          AttendanceRepository a, LeaveRepository l,
                          PayrollRepository p, NotificationRepository n,
                          UserRepository u){
        employees=e; salaryRepo=s; attendance=a; leaves=l; payrolls=p; notifications=n; users=u;
    }

    @Transactional
    public Payroll process(Long employeeId,int month,int year){
        Employee emp=employees.findById(employeeId).orElseThrow(()->new RuntimeException("Employee not found"));
        if(payrolls.findByEmployeeIdAndPayMonthAndPayYear(employeeId,month,year).isPresent())
            throw new RuntimeException("Payroll already exists for this employee and month");

        EmployeeSalary s=salaryRepo.findByEmployeeId(employeeId).orElseGet(()->{
            EmployeeSalary x=new EmployeeSalary(); x.setEmployee(emp); return salaryRepo.save(x);
        });

        YearMonth ym=YearMonth.of(year,month);
        LocalDate start=ym.atDay(1), end=ym.atEndOfMonth();
        List<Attendance> records=attendance.findByEmployeeIdAndWorkDateBetween(employeeId,start,end);
        int workingDays=ym.lengthOfMonth();
        int present=(int)records.stream().filter(x->x.getStatus()==AttendanceStatus.PRESENT).count();
        int leave=(int)records.stream().filter(x->x.getStatus()==AttendanceStatus.LEAVE).count();
        double overtime=records.stream().mapToDouble(Attendance::getOvertimeHours).sum();

        BigDecimal basic=nz(emp.getBasicSalary());
        BigDecimal hra=nz(s.getHra());
        BigDecimal allowances=nz(s.getTransportAllowance()).add(nz(s.getOtherAllowance()));
        BigDecimal overtimePay=nz(s.getOvertimeRate()).multiply(BigDecimal.valueOf(overtime));
        BigDecimal bonus=nz(s.getBonus());

        BigDecimal daily=workingDays==0?BigDecimal.ZERO:basic.divide(BigDecimal.valueOf(workingDays),2,RoundingMode.HALF_UP);
        BigDecimal leaveDeduction=daily.multiply(BigDecimal.valueOf(leave));
        BigDecimal gross=basic.add(hra).add(allowances).add(overtimePay).add(bonus);
        BigDecimal other=nz(s.getOtherDeduction());
        BigDecimal total=leaveDeduction.add(other);
        BigDecimal net=gross.subtract(total);

        Payroll p=new Payroll();
        p.setEmployee(emp); p.setPayMonth(month); p.setPayYear(year);
        p.setWorkingDays(workingDays); p.setPresentDays(present); p.setLeaveDays(leave);
        p.setOvertimeHours(overtime); p.setBasicSalary(basic); p.setHra(hra);
        p.setAllowances(allowances); p.setOvertimePay(overtimePay); p.setBonus(bonus);
        p.setGrossSalary(gross); p.setLeaveDeduction(leaveDeduction);
        p.setOtherDeductions(other); p.setTotalDeductions(total); p.setNetSalary(net);
        p.setStatus(PayrollStatus.PENDING);

        Optional<Payroll> previous=payrolls.findByEmployeeId(employeeId).stream()
            .max(Comparator.comparing(Payroll::getPayYear).thenComparing(Payroll::getPayMonth));
        if(previous.isPresent() && previous.get().getNetSalary().compareTo(BigDecimal.ZERO)>0){
            BigDecimal old=previous.get().getNetSalary();
            BigDecimal change=net.subtract(old).abs().divide(old,4,RoundingMode.HALF_UP);
            if(change.compareTo(new BigDecimal("0.50"))>0){
                p.setAnomaly(true);
                p.setAnomalyMessage("Unusual payroll amount detected. Please verify bonus, overtime or deductions.");
            }
        }
        Payroll saved=payrolls.save(p);
        users.findByUsername(emp.getUser()!=null?emp.getUser().getUsername():"").ifPresent(u->{
            Notification n=new Notification(); n.setUser(u);
            n.setMessage("Payroll generated for "+ym+". Status: PENDING.");
            notifications.save(n);
        });
        return saved;
    }

    private BigDecimal nz(BigDecimal v){return v==null?BigDecimal.ZERO:v;}
}
